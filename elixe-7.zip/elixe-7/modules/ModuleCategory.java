package elixe.modules;

public enum ModuleCategory {
PLAYER,
RENDER,
COMBAT,
WORLD,
MOVEMENT,
MISC
}
