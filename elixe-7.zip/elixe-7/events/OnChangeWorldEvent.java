package elixe.events;

public class OnChangeWorldEvent {

}
