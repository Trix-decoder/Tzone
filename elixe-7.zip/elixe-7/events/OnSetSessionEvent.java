package elixe.events;

public class OnSetSessionEvent {

}
