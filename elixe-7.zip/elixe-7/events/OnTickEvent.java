package elixe.events;

//runTick() : void - net.minecraft.client.Minecraft
//L:1579
public class OnTickEvent {

}
