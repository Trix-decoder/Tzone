package elixe.events;

import me.zero.alpine.event.type.Cancellable;

public class OnNauseaScaleEvent extends Cancellable{

}
