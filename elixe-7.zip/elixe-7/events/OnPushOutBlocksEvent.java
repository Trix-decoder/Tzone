package elixe.events;

import me.zero.alpine.event.type.Cancellable;

//pushOutOfBlocks(double, double, double) : boolean - net.minecraft.client.entity.EntityPlayerSP
//L:463
public class OnPushOutBlocksEvent extends Cancellable {

}
